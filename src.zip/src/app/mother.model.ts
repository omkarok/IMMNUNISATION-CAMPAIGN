export class Mother {
    constructor(
        public first_name: string,
        public last_name: string,
        public rch_id: string,
        public location: string,
        public mobile: string,
        public date_of_birth: string,
        public blood_group: string,
        public delivery_complication: string,
        public education: string
      ) { }
}
