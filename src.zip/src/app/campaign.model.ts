export class Campaign {
    constructor(
        public campaign_id: string,
        public is_mobile: string,
        public Organiser: string,
        public location: string,
        public st_dt: string,
        public end_dt: string,
        
      ) { }
}
